module.exports = {
    index: function(req, res){
        res.send('Home')
    },
    store: function(req, res){
        res.send('Guardando sesion')
    }
}